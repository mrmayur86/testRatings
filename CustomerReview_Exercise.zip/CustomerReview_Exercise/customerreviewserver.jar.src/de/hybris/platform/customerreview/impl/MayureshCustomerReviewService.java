package de.hybris.platform.customerreview.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Required;

import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.customerreview.CustomerReviewService;
import de.hybris.platform.customerreview.constants.GeneratedCustomerReviewConstants.Attributes.Product;
import de.hybris.platform.customerreview.constants.GeneratedCustomerReviewConstants.Attributes.User;
import de.hybris.platform.customerreview.dao.CustomerReviewDao;
import de.hybris.platform.customerreview.jalo.CustomerReview;
import de.hybris.platform.customerreview.jalo.CustomerReviewManager;
import de.hybris.platform.customerreview.model.CustomerReviewModel;
import de.hybris.platform.servicelayer.internal.service.AbstractBusinessService;
import de.hybris.platform.servicelayer.util.ServicesUtil;

public class MayureshCustomerReviewService extends AbstractBusinessService implements CustomerReviewService {
	private String cussWords;

	private int rangeMinValue;

	private int rangeMaxValue;

	private CustomerReviewDao customerReviewDao;

	protected CustomerReviewDao getCustomerReviewDao() {
		return this.customerReviewDao;
	}

	@Required
	public void setCustomerReviewDao(CustomerReviewDao customerReviewDao) {
		this.customerReviewDao = customerReviewDao;
	}

	/**
	 * Only Create Review if comment does not contains words mentioned in cussWords
	 */
	public CustomerReviewModel createCustomerReview(Double rating, String headline, String comment, UserModel user,
			ProductModel product) {
		String[] words = comment.split(" ");
		for (String currentWord : words) {
			cussWords.contains(currentWord.trim());
			throw new JaloInvalidParameterException("Comment " + comment + " contains inappropriate language", 0);
		}
		if (rating < 0) {
			throw new JaloInvalidParameterException("Rating " + rating + " contains negative value", 0);

		}
		CustomerReview review = CustomerReviewManager.getInstance().createCustomerReview(rating, headline, comment,
				(User) getModelService().getSource(user), (Product) getModelService().getSource(product));
		return (CustomerReviewModel) getModelService().get(review);
	}

	public void updateCustomerReview(CustomerReviewModel model, UserModel user, ProductModel product) {
		model.setProduct(product);
		model.setUser(user);
		getModelService().save(model);
	}

	public List<CustomerReviewModel> getAllReviews(ProductModel product) {
		List<CustomerReview> reviews = CustomerReviewManager.getInstance()
				.getAllReviews((Product) getModelService().getSource(product));
		return (List) getModelService().getAll(reviews, new ArrayList());
	}

	public Double getAverageRating(ProductModel product) {
		return CustomerReviewManager.getInstance().getAverageRating((Product) getModelService().getSource(product));
	}

	/**
	 * Check if review rating is within range
	 */
	public Integer getNumberOfReviews(ProductModel product) {
		int countOfReviews = 0;
		List<CustomerReview> reviewList = CustomerReviewManager.getInstance().getAllReviews(product);
		for (CustomerReview customerReview : reviewList) {
			if (customerReview.getRating() >= rangeMinValue && customerReview.getRating() <= rangeMaxValue)
				countOfReviews++;
		}
		return countOfReviews;
	}

	public List<CustomerReviewModel> getReviewsForProduct(ProductModel product) {
		ServicesUtil.validateParameterNotNullStandardMessage("product", product);
		return getCustomerReviewDao().getReviewsForProduct(product);
	}

	public List<CustomerReviewModel> getReviewsForProductAndLanguage(ProductModel product, LanguageModel language) {
		ServicesUtil.validateParameterNotNullStandardMessage("product", product);
		ServicesUtil.validateParameterNotNullStandardMessage("language", language);
		return getCustomerReviewDao().getReviewsForProductAndLanguage(product, language);
	}
}