package de.hybris.platform.customerreview.impl;

abstract interface package-info {}