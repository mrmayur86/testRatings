package de.hybris.platform.customerreview;

abstract interface package-info {}