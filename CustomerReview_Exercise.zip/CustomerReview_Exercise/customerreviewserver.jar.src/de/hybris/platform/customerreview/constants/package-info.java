package de.hybris.platform.customerreview.constants;

abstract interface package-info {}