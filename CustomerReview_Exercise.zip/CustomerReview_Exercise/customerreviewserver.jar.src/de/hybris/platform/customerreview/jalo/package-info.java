package de.hybris.platform.customerreview.jalo;

abstract interface package-info {}